#include <llvm/IR/BasicBlock.h>
#include <llvm/IR/Constants.h>
#include <llvm/IR/DerivedTypes.h>
#include <llvm/IR/Function.h>
#include <llvm/IR/IRBuilder.h>
#include <llvm/IR/LLVMContext.h>
#include <llvm/IR/Module.h>
#include <llvm/IR/Type.h>
#include <llvm/IR/Verifier.h>

#include <iostream>
#include <memory>

#ifdef DEBUG  
#define DEBUG_OUTPUT std::cout << __LINE__ << std::endl;  
#else
#define DEBUG_OUTPUT
#endif

using namespace llvm;
#define CONST(num) \
  ConstantInt::get(context, APInt(32, num)) 

int main() {
  LLVMContext context;
  Type *TYPE32 = Type::getInt32Ty(context);
  IRBuilder<> builder(context);
  auto module = new Module("if", context); 
  
  auto mainFun = Function::Create(FunctionType::get(TYPE32, false),
                                  GlobalValue::LinkageTypes::ExternalLinkage,
                                  "main", module);
  auto bb = BasicBlock::Create(context, "entry", mainFun);
  builder.SetInsertPoint(bb);  //前面全部按照所给例子仿写
  
  auto retAlloca = builder.CreateAlloca(TYPE32);    //返回值内存分配
  auto icmp= builder.CreateICmpSGT(CONST(2),CONST(1));  //直接用常数进行函数比较
  
  auto trueBB = BasicBlock::Create(context, "trueBB", mainFun);    
  auto falseBB = BasicBlock::Create(context, "falseBB", mainFun); 
  auto retBB = BasicBlock::Create(
      context, "", mainFun);   //设置分支
  auto br = builder.CreateCondBr(icmp, trueBB, falseBB);   //分支跳转
  //由于我安装的是Release版本，所以就没有保留Debug相关内容
  builder.SetInsertPoint(trueBB);   //进入true分支
  builder.CreateStore(CONST(1), retAlloca);
  builder.CreateBr(retBB);            //将1赋值给返回值，进入return块

  builder.SetInsertPoint(falseBB); 
  //进入false分支（原函数为单if，这样写比较像if-else，但是好像只有这种写法）
  builder.CreateStore(CONST(0), retAlloca);
  builder.CreateBr(retBB);

  builder.SetInsertPoint(retBB); 
  auto retLoad = builder.CreateLoad(retAlloca);
  builder.CreateRet(retLoad);
  builder.ClearInsertionPoint();
  //return分支，因为值已经给空间地址赋值好，所以直接返回值

  module->print(outs(), nullptr);
  delete module;
  return 0;  //输出并释放内存
}

#include <llvm/IR/BasicBlock.h>
#include <llvm/IR/Constants.h>
#include <llvm/IR/DerivedTypes.h>
#include <llvm/IR/Function.h>
#include <llvm/IR/IRBuilder.h>
#include <llvm/IR/LLVMContext.h>
#include <llvm/IR/Module.h>
#include <llvm/IR/Type.h>
#include <llvm/IR/Verifier.h>

#include <iostream>
#include <memory>

#ifdef DEBUG  
#define DEBUG_OUTPUT std::cout << __LINE__ << std::endl;  
#else
#define DEBUG_OUTPUT
#endif

using namespace llvm;  
#define CONST(num) \
  ConstantInt::get(context, APInt(32, num))  
int main() {
  LLVMContext context;
  Type *TYPE32 = Type::getInt32Ty(context);
  IRBuilder<> builder(context);
  auto module = new Module("call", context); 
 //前面全部按照所给例子仿写
   std::vector<Type *> Ints(1, TYPE32);
  auto calleeFun = Function::Create(FunctionType::get(TYPE32, Ints, false),
                                 GlobalValue::LinkageTypes::ExternalLinkage,
                                 "callee", module);
  //按照期望的输出顺序，先写callee函数,有一个参数
  auto bb = BasicBlock::Create(context, "entry", calleeFun);
  builder.SetInsertPoint(bb);                     
  auto retAlloca = builder.CreateAlloca(TYPE32);  //返回值内存分配
  auto aAlloca = builder.CreateAlloca(TYPE32);   
   std::vector<Value *> args; 
  for (auto arg = calleeFun->arg_begin(); arg != calleeFun->arg_end(); arg++) {
    args.push_back(arg);
  }                                      //获取callee函数参数
   builder.CreateStore(args[0], aAlloca);  //将参数a store下来
  auto aLoad = builder.CreateLoad(aAlloca);//将参数a load上来
  auto mul = builder.CreateNSWMul(CONST(2),aLoad); 
  builder.CreateStore(mul, retAlloca);//计算乘积并直接store给返回值的内存空间
  auto retLoad = builder.CreateLoad(retAlloca);
  builder.CreateRet(retLoad);//return，callee函数结束

 
   auto mainFun = Function::Create(FunctionType::get(TYPE32, false),
                                  GlobalValue::LinkageTypes::ExternalLinkage,
                                  "main", module);//main函数
  bb = BasicBlock::Create(context, "entry", mainFun);
  builder.SetInsertPoint(bb);
  
  auto call = builder.CreateCall(calleeFun, {CONST(10)});
  //call调用callee函数,直接传值常数10
  builder.CreateRet(call);//将call的返回值直接return，不用设置返回值内存分配
 
  module->print(outs(), nullptr);
  delete module;
  return 0;//输出并释放内存
}

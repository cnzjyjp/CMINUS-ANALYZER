#include <llvm/IR/BasicBlock.h>
#include <llvm/IR/Constants.h>
#include <llvm/IR/DerivedTypes.h>
#include <llvm/IR/Function.h>
#include <llvm/IR/IRBuilder.h>
#include <llvm/IR/LLVMContext.h>
#include <llvm/IR/Module.h>
#include <llvm/IR/Type.h>
#include <llvm/IR/Verifier.h>

#include <iostream>
#include <memory>

#ifdef DEBUG  
#define DEBUG_OUTPUT std::cout << __LINE__ << std::endl;  
#else
#define DEBUG_OUTPUT
#endif

using namespace llvm;  
#define CONST(num) \
  ConstantInt::get(context, APInt(32, num))  

int main() {
  LLVMContext context;
  Type *TYPE32 = Type::getInt32Ty(context);
  IRBuilder<> builder(context);
  auto module = new Module("while", context); 
  
  auto mainFun = Function::Create(FunctionType::get(TYPE32, false),
                                  GlobalValue::LinkageTypes::ExternalLinkage,
                                  "main", module);
  auto bb = BasicBlock::Create(context, "entry", mainFun);
  builder.SetInsertPoint(bb);
//前面全部按照所给例子仿写
  auto aAlloca = builder.CreateAlloca(TYPE32);//a内存分配
  auto iAlloca = builder.CreateAlloca(TYPE32);//i内存分配
  auto retAlloca = builder.CreateAlloca(TYPE32);//返回值内存分配

  builder.CreateStore(CONST(10), aAlloca);
  builder.CreateStore(CONST(0), iAlloca);

  auto aLoad = builder.CreateLoad(aAlloca);
  auto iLoad = builder.CreateLoad(iAlloca);
  //a,i的空间地址内容目前为10和0，并且已经Load
  auto add = builder.CreateNSWAdd(iLoad, CONST(0));
  //由于add定义的时候要求要有初始值，所以先设立为i+0
  auto whileBB = BasicBlock::Create(context, "whileBB", mainFun);
  //while表示在循环体
  auto endBB = BasicBlock::Create(context, "endBB", mainFun);
  //end表示刚刚离开循环体
  auto Branch = BasicBlock::Create(context, "Branch", mainFun);
  //branch表示在while的判断条件中
  auto retBB = BasicBlock::Create(
      context, "", mainFun);  
  //由于我安装的是Release版本，所以就没有保留Debug相关内容
  builder.CreateBr(Branch);
  //先进入branch判断循环条件
  builder.SetInsertPoint(Branch); 
  iLoad = builder.CreateLoad(iAlloca);
  auto icmp = builder.CreateICmpSLT(iLoad,CONST(10));
  builder.CreateCondBr(icmp, whileBB, endBB);
 
  builder.SetInsertPoint(whileBB);
  //执行循环体，需要小心变量到底是值还是指针 
  add = builder.CreateNSWAdd(iLoad, CONST(1));//add=i+1
  builder.CreateStore(add, iAlloca); //store add to ipointer
  iLoad = builder.CreateLoad(iAlloca);  //load i
  aLoad = builder.CreateLoad(aAlloca);  //load a
  add = builder.CreateNSWAdd(aLoad, iLoad);  //add=a+i
  builder.CreateStore(add, aAlloca);  //store add to apointer
  builder.CreateBr(Branch);  //再次进入branch判断是否继续while

  builder.SetInsertPoint(endBB); //branch结束的end过渡，接下来直接进return
  builder.CreateBr(retBB);

  builder.SetInsertPoint(retBB); 
  aLoad = builder.CreateLoad(aAlloca);
  builder.CreateStore(aLoad, retAlloca);
  auto retLoad = builder.CreateLoad(retAlloca);
  builder.CreateRet(retLoad);//读取a的值并返回

  builder.ClearInsertionPoint();
 
  module->print(outs(), nullptr);
  delete module;
  return 0;//输出并释放内存
}


#include <llvm/IR/BasicBlock.h>
#include <llvm/IR/Constants.h>
#include <llvm/IR/DerivedTypes.h>
#include <llvm/IR/Function.h>
#include <llvm/IR/IRBuilder.h>
#include <llvm/IR/LLVMContext.h>
#include <llvm/IR/Module.h>
#include <llvm/IR/Type.h>
#include <llvm/IR/Verifier.h>

#include <iostream>
#include <memory>

#ifdef DEBUG  
#define DEBUG_OUTPUT std::cout << __LINE__ << std::endl; 
#else
#define DEBUG_OUTPUT
#endif

using namespace llvm;  
#define CONST(num) \
  ConstantInt::get(context, APInt(32, num)) 
int main() {
  LLVMContext context;
  Type *TYPE32 = Type::getInt32Ty(context);
  IRBuilder<> builder(context);
  auto module = new Module("assign", context);

  auto mainFun = Function::Create(FunctionType::get(TYPE32, false),
                                  GlobalValue::LinkageTypes::ExternalLinkage,
                                  "main", module);
 
  auto bb = BasicBlock::Create(context, "entry", mainFun);
  builder.SetInsertPoint(bb);                     // 前面全部按照所给例子仿写
  auto retAlloca = builder.CreateAlloca(TYPE32);  // 返回值的空间分配
  auto aAlloca = builder.CreateAlloca(TYPE32);    // 参数a的空间分配
  builder.CreateStore(CONST(1), aAlloca);         //将1 store给a的空间地址
  auto aLoad = builder.CreateLoad(aAlloca);       //a的值Load上来
  builder.CreateStore(aLoad, retAlloca);          //同理将返回值赋值为a
  auto retLoad = builder.CreateLoad(retAlloca);   
  builder.CreateRet(retLoad);                      //返回
  
  module->print(outs(), nullptr);
  delete module;
  return 0;                           //输出并释放内存
}

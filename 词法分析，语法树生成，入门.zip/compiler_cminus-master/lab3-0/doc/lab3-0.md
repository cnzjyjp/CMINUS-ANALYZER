## lab3-0实验报告

严嘉鹏

PB17111632

### 实验要求

1.准备实验环境：安装LLVM8.0.1源码并编译安装，配置生成的二进制文件路径；

2.根据自动生成的`gcd.ll`文件内容，学习LLVM IR，并手工编写要求的的四个`.ll`文件，用`lli`检查结果的正确性；

3.根据助教给的`gcd_generator.cpp`,学习cpp翻译的编写，编写要求的四个`.cpp`文件，检验其输出结果的正确性；

### 实验结果

以下`.ll`文件为cpp翻译生成。

###### assign:

```
define i32 @main() {
entry:
  %0 = alloca i32
  %1 = alloca i32
  store i32 1, i32* %1
  %2 = load i32, i32* %1
  store i32 %2, i32* %0
  %3 = load i32, i32* %0
  ret i32 %3
}
```

assign没什么好说的，只有一个entry块，对应代码部分是

```
  auto bb = BasicBlock::Create(context, "entry", mainFun);
  builder.SetInsertPoint(bb);  
```

###### if:

```
define i32 @main() {
entry:
  %0 = alloca i32
  br i1 true, label %trueBB, label %falseBB

trueBB:                                           ; preds = %entry
  store i32 1, i32* %0
  br label %1

falseBB:                                          ; preds = %entry
  store i32 0, i32* %0
  br label %1

; <label>:1:                                      ; preds = %falseBB, %trueBB
  %2 = load i32, i32* %0
  ret i32 %2
}
```

if共有entry、trueBB、falseBB、\<label\>:1四个BasicBlock；

对应cpp代码为

```
 auto bb = BasicBlock::Create(context, "entry", mainFun);
 auto trueBB = BasicBlock::Create(context, "trueBB", mainFun);    
 auto falseBB = BasicBlock::Create(context, "falseBB", mainFun); 
 auto retBB = BasicBlock::Create(
      context, "", mainFun); 
```

因为retBB没有自定义命名所以没有命名部分，只是用注释;\<label\>:12代替；

```
builder.SetInsertPoint(bb);
...
auto br = builder.CreateCondBr(icmp, trueBB, falseBB);  

builder.SetInsertPoint(trueBB);   
...
builder.CreateBr(retBB);   

builder.SetInsertPoint(falseBB); 
...
builder.CreateBr(retBB);

builder.SetInsertPoint(retBB); 
...

builder.ClearInsertionPoint();
```

因此entry块的结尾就是br分支到trueBB或者falseBB,而trueBB和falseBB的结尾都会到retBB即\<label\>1的位置，结束程序。

###### while:

```
define i32 @main() {
entry:
  %0 = alloca i32
  %1 = alloca i32
  %2 = alloca i32
  store i32 10, i32* %0
  store i32 0, i32* %1
  %3 = load i32, i32* %0
  %4 = load i32, i32* %1
  %5 = add nsw i32 %4, 0
  br label %Branch

whileBB:                                          ; preds = %Branch
  %6 = add nsw i32 %10, 1
  store i32 %6, i32* %1
  %7 = load i32, i32* %1
  %8 = load i32, i32* %0
  %9 = add nsw i32 %8, %7
  store i32 %9, i32* %0
  br label %Branch

endBB:                                            ; preds = %Branch
  br label %12

Branch:                                           ; preds = %whileBB, %entry
  %10 = load i32, i32* %1
  %11 = icmp slt i32 %10, 10
  br i1 %11, label %whileBB, label %endBB

; <label>:12:                                     ; preds = %endBB
  %13 = load i32, i32* %0
  store i32 %13, i32* %2
  %14 = load i32, i32* %2
  ret i32 %14
}
```

while共有entry、Branch、whileBB、endBB、\<label\>:12五个BasicBlock；

对应cpp代码为

```
 auto bb = BasicBlock::Create(context, "entry", mainFun);
 auto Branch = BasicBlock::Create(context, "Branch", mainFun);    
 auto whileBB = BasicBlock::Create(context, "whileBB", mainFun);    
 auto endBB = BasicBlock::Create(context, "endBB", mainFun); 
 auto retBB = BasicBlock::Create(
      context, "", mainFun); 
```

因为retBB没有自定义命名所以没有命名部分，所以只是用注释;\<label\>:12代替；

```
  builder.SetInsertPoint(bb);
  ...
  
  builder.SetInsertPoint(Branch); 
  ...
  builder.CreateCondBr(icmp, whileBB, endBB);
 
  builder.SetInsertPoint(whileBB);
  ...
  builder.CreateBr(Branch); 
  
  builder.SetInsertPoint(endBB); 
  builder.CreateBr(retBB);

  builder.SetInsertPoint(retBB); 
  ...
  
  builder.ClearInsertionPoint();
```

所以BasicBlock之间的结构为从entry进入后，进入Branch块，icmp记录i是否小于10，是则进入whileBB块执行循环体，然后在whileBB块结束时回到Branch进行是否继续循环的判定；否则进入endBB块过渡到retBB块（其实可以Branch直接跳转到retBB块，对于这个`while.c`例子逻辑上是一样的，对于泛用性的while则是直接跳到while结束后内容对应的块），retBB块返回值，然后结束程序。

###### call:

```
define i32 @callee(i32) {
entry:
  %1 = alloca i32
  %2 = alloca i32
  store i32 %0, i32* %2
  %3 = load i32, i32* %2
  %4 = mul nsw i32 2, %3
  store i32 %4, i32* %1
  %5 = load i32, i32* %1
  ret i32 %5
}

define i32 @main() {
entry:
  %0 = call i32 @callee(i32 10)
  ret i32 %0
}
```

call分为两个函数，分别都只有一个entry块。

对应cpp翻译代码为：

```
 auto calleeFun = ...
 auto bb = BasicBlock::Create(context, "entry", calleeFun);
 builder.SetInsertPoint(bb);                     
 ...
 builder.CreateRet(retLoad);
 
 auto mainFun = ...
 bb = BasicBlock::Create(context, "entry", mainFun);
 builder.SetInsertPoint(bb);
 ...
 auto call = builder.CreateCall(calleeFun, {CONST(10)});
 builder.CreateRet(call);
```

main函数和assign一样只有一个entry基本块，直接进入，执行到最后call callee函数，进入callee函数，一样只有一个entry块，进入callee的entry块然后结束。即生成两个函数，每个函数只有一个entry基本块，在main中调用callee函数。

### 实验难点

##### 1.gcc版本的升级

我的Unbuntu是14.04的，gcc版本过低（4.8.4，要求最低5.2.0），试了很多网上的指令都不能用，甚至装了高版本gcc但并不能覆盖低版本，将高版本设为默认优先后编译llvm的cmake指令还是表示版本过低。最后直接安装了16.04的Ubuntu，自带gcc版本就够用了。

##### 2.PATH的配置

助教所给的配置方法是适用于默认shell为zsh的，而windows系统的Ubuntu虚拟机默认shell是bash;我本来打算搜索bash的配置方法，但是比较麻烦（很多网上的说法不能用），所以最后选择安装zsh并将其设定为默认shell；然后出现的问题是`su root`指令在zsh作为默认shell的情况下不能获取root权限了。要解决这个问题获取root权限就要修改`/etc`目录下的passwd文件，但是没有root权限又不能修改这个文件（互锁千古难题）。而不获取root权限就只能切换用户的默认shell，root的默认shell改不了了（不知道只改用户默认shell是不是就能用了）。网上说法是直接将zsh卸载就好了，因为还要用zsh而且暂时用不到root权限，所以就先不管了。（但是在root默认shell是zsh的情况下还能把zsh卸载吗?有所怀疑。)

##### 3.LLVM IR文件的编写

中途出现的几个问题有：

结构格式：基本对着自动生成的`.ll`仿写的，尝试性删掉了所有能删的东西，例如函数以外的所有内容（注释、`source_filename=...`等）,而且把函数后面的`#0`删掉了（并没有查到有什么用）；

三地址"="语句的第一个地址必须按序出现而且只能用一次，导致while比较难写；

`alloca`、`store`、`load`涉及的对象类型（数值还是指针）；

一些保留字比较难查（例如大于，而且大于等于sge可能是插件问题，甚至不是保留字），或者说语法的一些细节比较难查;

branch结构：如果没有特定赋值，则默认占用下一个顺序地址作为label值。例如：

```
%7...
branch i1 %7 ...
```

 那么如果接下来是跳转部分的话label就默认为%8,下一个"="语句的第一个地址将从%9开始;

带参数的函数将默认占用地址，例如有一个参数的函数第一个地址就要从%2开始（而且函数之间地址计数不会累加，如gcd中%3的使用并不影响main从%1开始用到%5）。

##### 4.cpp文件的编写

涉及的难点有：

结构格式：基本对着gcd_generator仿写的；

`builder.CreateAlloca`、`builder.CreateStore`、`builder.CreateLoad`涉及的对象类型（数值还是指针）；

branch结构的编写格式。

**总的来说，这次实验因为有比较复杂完善的范本，所以编写较为简单的文件时就比较容易，一些问题都能在范例中找到正确的例子。**

### 实验总结

通过本次实验：

学习了LLVM环境的安装；

对LLVM IR的语法略懂皮毛了，能够手动编写简单的LLVM IR文件；

按照助教所给的`.cpp`文件仿写了四个cpp翻译程序，对通过cpp自动根据AST生成LLVM IR文件所需要的cpp程序的编写方法有所涉猎。
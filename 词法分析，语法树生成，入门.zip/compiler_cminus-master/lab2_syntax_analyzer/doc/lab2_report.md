
## Lab2-实验报告

严嘉鹏

PB17111632

#### 实验内容

依据lab1完成的lexical_analyzer.l文件，将lab1文件夹中的文件补全；补全syntax_analyzer.y文件代码；从而对于一个testcase能用flex完成词法分析接着用bison完成语法分析。

根据报错和warning修正代码。

在能正确生成.syntax_tree文件的情况下，和助教提供的样例比对，根据错误修正代码。

根据Bison的warning发现了潜在的移进-归约冲突，用Bison的-v指令输出.output文件，定位冲突，将文法修改为无冲突的文法。

最终生成无冲突的和助教提供样例一致的.syntax_tree文件，完成Bison语法分析任务。

#### 实验设计

1.文件读取方面：这次由于提供了21个testcase，所以要将filename[10]扩充到至少大于21；另外getAllTestcase被划分到common.c文件中，必须单独给该文件补充应该include的头文件，而且该函数变成了int类型以传递文件总数，也需要对lab1的lex_main函数进行修改。

2.syntax_analyzer.y文件的编写：先补充好token和优先级声明；按照CMINUS.md，编写文法和对于语法树的输出情况；函数部分并不需要修改。值得注意的时yyerror函数需要输出错误的行数，而lexical_analyzer.l的analyze函数是不与.y文件共享的，只共享模式动作，所以对于EOL应该把行数增加写在动作里而不是analyzer的switch(token)选项中。另外例如EOL、COMMENT、BLANK，并不需要语法分析树的输出，因此虽然在两个文件中都设立了token,但是我并没有对于这三种token有return的情况（应该计数的操作仍然进行）。

3.union结构的设计和构建语法树的输出：大致是通过查找资料和查阅助教的CMINUS.md模仿着写的，union有一个问题是如果定义指针为`SyntaxTreeNode`就要在.l文件中额外include头文件SyntaxTree.h，而如果定义成`struct _SyntaxTreeNode`就不需要。具体原因也不是很明白，因为SyntaxTree.h里明明有`typedef struct _SyntaxTreeNode SyntaxTreeNode;`的语句。而关于语法树中空串的处理产生的问题见实验难点部分3。

4.flex和bison的共享数据结构实现：

将token存在lexical_analyzer.h文件中，在lexical_analyzer.l调用.h文件以定义token，进一步写模式动作，在syntax_analyzer.y中进一步设立token数据类型和优先级。这样就共享了token的目录，而在词法分析中追加动作，在语法分析中追加定义数据类型和优先级。进一步，在.l文件中定义`YYSTYPE yylval;`将num和identifier的特殊数据类型char*传值需求满足:

```
#ifndef LAB1_ONLY
yylval.str = strdup(yytext);
#endif
```

此外在.y文件中声明`extern int lines;`使得.y文件共享.l文件中的lines（行数统计）。

5.过滤词法分析中无用的词法符号：

在lexical_analyzer.l中保留注释、换行、空白对于pos_start、pos_end、lines的操作；但是EOL、BLANK、COMMENT将不会return（即使它们被定义了），即在动作中完成对于pos_start、pos_end、lines的操作，而没有token类型将会返回到analyzer函数中。这样在.y文件中也得不到return，将会自动过滤，另外由于lines的增加在动作中，因此语法分析出现error时也能输出正确的行数（另外一个值得注意的点是每次开始一个新testcase的语法分析时要将lines重置为1)。

6.关于二义性文法（移进-归约冲突）：见实验难点部分4。

#### 实验结果

在正确路径输出.syntax_tree文件。该文件和助教的文件用diff命令检查发现内容一致（除了因为lab1时testcase有一个自行编写的样例所以syntree文件夹里多了一个.syntax_tree文件）。

**具体难点上，**

**1.实现了flex和bison的共享数据结构；**

**2.过滤了词法分析中无用的词法符号；**

**3.二义性文法方面，用bison定位了潜在的移进-归约冲突的位置，并修正文法将其解决。**

样例举例：（找了一个比较少的能正常输出的testcase，不然动辄几百行太多了)

lab2_call.cminus

```
int main(void)
{
	a = b = c + d;
	return 0;
}
```

输出结果

>```
>>--+ program
>|  >--+ declaration-list
>|  |  >--+ declaration
>|  |  |  >--+ fun-declaration
>|  |  |  |  >--+ type-specifier
>|  |  |  |  |  >--* int
>|  |  |  |  >--* main
>|  |  |  |  >--* (
>|  |  |  |  >--+ params
>|  |  |  |  |  >--* void
>|  |  |  |  >--* )
>|  |  |  |  >--+ compound-stmt
>|  |  |  |  |  >--* {
>|  |  |  |  |  >--+ local-declarations
>|  |  |  |  |  |  >--* epsilon
>|  |  |  |  |  >--+ statement-list
>|  |  |  |  |  |  >--+ statement-list
>|  |  |  |  |  |  |  >--+ statement-list
>|  |  |  |  |  |  |  |  >--* epsilon
>|  |  |  |  |  |  |  >--+ statement
>|  |  |  |  |  |  |  |  >--+ expression-stmt
>|  |  |  |  |  |  |  |  |  >--+ expression
>|  |  |  |  |  |  |  |  |  |  >--+ var
>|  |  |  |  |  |  |  |  |  |  |  >--* a
>|  |  |  |  |  |  |  |  |  |  >--* =
>|  |  |  |  |  |  |  |  |  |  >--+ expression
>|  |  |  |  |  |  |  |  |  |  |  >--+ var
>|  |  |  |  |  |  |  |  |  |  |  |  >--* b
>|  |  |  |  |  |  |  |  |  |  |  >--* =
>|  |  |  |  |  |  |  |  |  |  |  >--+ expression
>|  |  |  |  |  |  |  |  |  |  |  |  >--+ simple-expression
>|  |  |  |  |  |  |  |  |  |  |  |  |  >--+ additive-expression
>|  |  |  |  |  |  |  |  |  |  |  |  |  |  >--+ additive-expression
>|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  >--+ term
>|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  >--+ factor
>|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  >--+ var
>|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  >--* c
>|  |  |  |  |  |  |  |  |  |  |  |  |  |  >--+ addop
>|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  >--* +
>|  |  |  |  |  |  |  |  |  |  |  |  |  |  >--+ term
>|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  >--+ factor
>|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  >--+ var
>|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  >--* d
>|  |  |  |  |  |  |  |  |  >--* ;
>|  |  |  |  |  |  >--+ statement
>|  |  |  |  |  |  |  >--+ return-stmt
>|  |  |  |  |  |  |  |  >--* return
>|  |  |  |  |  |  |  |  >--+ expression
>|  |  |  |  |  |  |  |  |  >--+ simple-expression
>|  |  |  |  |  |  |  |  |  |  >--+ additive-expression
>|  |  |  |  |  |  |  |  |  |  |  >--+ term
>|  |  |  |  |  |  |  |  |  |  |  |  >--+ factor
>|  |  |  |  |  |  |  |  |  |  |  |  |  >--* 0
>|  |  |  |  |  |  |  |  >--* ;
>|  |  |  |  |  >--* }
>```

函数调用的顺序（无ERROR情况）：[**syntax_main**→getAllTestcase→syntax_main→strstr→syntax_main→strncpy→syntax_main→strcpy→syntax_main→[**syntax**→newSyntaxTree→strcat→syntax→strcat→syntax→fopen→yyrestart→syntax→printf→syntax→fopen→syntax→yyparse→[...(**yyparse**中的函数，包括若干次newSyntaxTree,SyntaxTreeNode_AddChild和free)]→**syntax**→printf→syntax→printSyntaxTree→syntax→deleteSyntaxTree→syntax→fclose→syntax→printf→syntax]→**syntax_main**]。

由于内容还是过多了，所以挑一句分析：

```
a = b = c + d;
```

对应树为

```
|  |  |  |  |  |  |  >--+ statement
|  |  |  |  |  |  |  |  >--+ expression-stmt
|  |  |  |  |  |  |  |  |  >--+ expression
|  |  |  |  |  |  |  |  |  |  >--+ var
|  |  |  |  |  |  |  |  |  |  |  >--* a
|  |  |  |  |  |  |  |  |  |  >--* =
|  |  |  |  |  |  |  |  |  |  >--+ expression
|  |  |  |  |  |  |  |  |  |  |  >--+ var
|  |  |  |  |  |  |  |  |  |  |  |  >--* b
|  |  |  |  |  |  |  |  |  |  |  >--* =
|  |  |  |  |  |  |  |  |  |  |  >--+ expression
|  |  |  |  |  |  |  |  |  |  |  |  >--+ simple-expression
|  |  |  |  |  |  |  |  |  |  |  |  |  >--+ additive-expression
|  |  |  |  |  |  |  |  |  |  |  |  |  |  >--+ additive-expression
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  >--+ term
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  >--+ factor
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  >--+ var
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  >--* c
|  |  |  |  |  |  |  |  |  |  |  |  |  |  >--+ addop
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  >--* +
|  |  |  |  |  |  |  |  |  |  |  |  |  |  >--+ term
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  >--+ factor
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  >--+ var
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  >--* d
|  |  |  |  |  |  |  |  |  >--* ;
```

分析树同一层的字符对应于产生式的右端，而前一个上一层的符号对应产生式的左端；该层的非终结符最后归约为终结符。树利用查看栈顶元素自下而上生成。

产生式顺序：

statement → expression-stmt | compound-stmt| selection-stmt| iteration-stmt | return-stmt

expression-stmt → expression ; | ;

expression → var `=` expression | simple-expression

var → `ID` | `ID` `[` expression `]`

expression → var `=` expression | simple-expression

var → `ID` | `ID` `[` expression `]`

expression → var `=` expression | simple-expression

simple-expression → additive-expression relop additive- expression | additive-expression

additive-expression → additive-expression addop term | term

term → term mulop factor | factor

factor → `(` expression `)` | var | call | `NUM`

var → `ID` | `ID` `[` expression `]`

addop → `+` | `-`

term → term mulop factor | factor

factor → `(` expression `)` | var | call | `NUM`

var → `ID` | `ID` `[` expression `]`

分号已由expression-stmt → expression ; | ;给出。

#### 实验难点

##### 1.lab1的遗留问题

**根据助教的反馈发现原来的注释忘记在识别跨行注释时增加行数，以及没法对于testcase中" x = x /\* \*/\*\*\**\*\*\*/4；"语句正确识别注释结构。**所以对lab1进行了修正，引入状态转换，INITIAL状态是非注释，COMMENT2状态为注释状态，对于不同状态进行不同操作，读入`/*`进入COMMENT2状态，读入`*/`退出，进入INITIAL状态。途中出现很多谜之bug，比如一定要把某些类型先写正则式定义然后在规则段中引用才能正确编译（之前直接在一些规则段的规则里写正则式定义，也编译运行通过了），还有些因为尝试性的操作直接解决了所以都不记得bug是什么了。这些可能是因为对lex缺乏系统性的学习导致的。最后结果是做到了生成的tokens与助教的TA_tokens完全一致了。

**2.刚开始词法分析时报错：syntax error:1 syntax error for**

这个error是因为lexical_analyzer和syntax_analyzer中对于token类型的赋值不同。lexical_analyzer.l中的token在lexical_analyzer.h中赋值了，而syntax_analyzer.y并没有赋值。因此.y文件中依据token出现的顺序进行了默认赋值，如果顺序不和.l文件中出现顺序完全一致就会导致同一个token的值在词法分析和语法分析中不同而报错。一个解决方案是在.y文件中定义token时追加定义token的值。即`%token <num> ERROR 258`而不是`%token <num> ERROR`。

**3.刚开始词法分析时报错：\*\*\* Error in `./build/test_syntax': double free or corruption (!prev): 0x0979c348 \*\*\***

这是对于**空串**的不正确处理导致的。

错误代码举例：

```
args:arg-list { $$ = newSyntaxTreeNode("args"); SyntaxTreeNode_AddChild($$,$1); }
	|
	;
```

正确的应该是：

```
args:arg-list { $$ = newSyntaxTreeNode("args"); SyntaxTreeNode_AddChild($$,$1); }
	|{ $$ = newSyntaxTreeNode("args"); SyntaxTreeNode_AddChild($$,newSyntaxTreeNode("epsilon")); }
	;
```

助教的样例中对于空串的输出是epsilon；但是即使不输出，`newSyntaxTreeNode`还是需要的，否则应该是在后面free的次数会产生问题（free代码并不在syntax_analyzer.y中，估计在yyparse的调用里）。

**4.移进归约冲突**

**在make步骤报了一个warning，内容是存在一个shift/reduce conflict。**

**如何定位：**查阅issue #74解决了这个问题。在lab2文件夹中用`bison -v syntax_analyzer.y`指令输出.output文件，将会指出`State 96 conflicts: 1 shift/reduce`，State 96如下：

```
State 96

   29 selection-stmt: IF LPARENTHESE expression RPARENTHESE statement .
   30               | IF LPARENTHESE expression RPARENTHESE statement . ELSE statement

ELSE  shift, and go to state 99

ELSE      [reduce using rule 29 (selection-stmt)]
$default  reduce using rule 29 (selection-stmt)
```

也就指出了.y文件中文法`selection-stmt:IF LPARENTHESE expression RPARENTHESE statement {...}| IF LPARENTHESE expression RPARENTHESE statement ELSE statement{...}`存在移进-归约冲突。正如issue #62提出的例子一样，对于`if ( expression ) if ( expression ) statement else statement`形式的内容，将会有两种合法的处理方式。

**如何解决：**查阅issue #62解决了这个问题。非常感谢回答的助教和同学们，因为仅凭我自己可能很难解决这个问题（一开始连解决方案里的`%nonassoc`声明和`%prec`修饰符都不知道）。

**5.Gitlab仓库如何merge？**

一开始我甚至是想一个一个文件手动上传的……

总之最后看着各种教程和在其他同学的帮助下以及助教的讲解及ppt的指导下完成了……但是感觉整个过程很曲折混乱，下次复现可能有困难。

#### 实验总结

这次实验感觉比较难顶，主要在于处理文件体系上的混乱，lab1错误的修正，以及过程中的坑比较多而且不易找到问题点。但是还算学到了一些东西，例如用于Bison语法分析的.y文件的编写语法，Bison、Cmake的几条简单命令，以及将多个文件编译连接为可执行文件的过程及其路径调用方法等，虽然付出的时间比较多不太成比例。

#### 实验反馈

如果助教对前几次lab文件的内容或结构进行改动（如这次lab2对lab1文件的改动），烦请写一个文档说明改动的具体内容（即我们要跟着修改哪些点），以避免我们自己的遗漏和错误，花费不必要的精力。当然最好就是在可以正常执行的情况下尽可能减少这次实验对上次实验文件的改动。

我觉得助教的说明文档应该写的更加详细，比如给出具体操作流程step(就像后来助教在周一追加的说明一样，但是我觉得那个merge还是讲的不够详细，可能是因为当天时间比较紧)，因为让我们自己摸索流程真的效率低下而且并不会比给出具体流程多学到什么东西，举个例子就是Gitlab仓库的merge，学会了就是学会了，助教给出具体操作方法和我们自己去探索并没有什么结果上的差别，自己探索还可能造成知识记忆上的混乱，以后相同操作反而容易犯错，而且助教和我们用的相同Gitlab，还能解决一些我们很难查阅到资料的问题。（举个例子，对于实验本身也是一样。）还有是常见bug的解决方案，比如助教自己在做这个实验过程中遇到的一些bug。


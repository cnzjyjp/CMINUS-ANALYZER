extern int syntax_main(int argc, char ** argv);

int main(int argc, char ** argv)
{
	return syntax_main(argc, argv);
}

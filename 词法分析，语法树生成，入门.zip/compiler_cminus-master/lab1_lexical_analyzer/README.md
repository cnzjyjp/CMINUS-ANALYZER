lab1 由 Guanbin Xu @gbxu , Yiduo Wang @duo 负责设计。若出现错误或疑惑，请在[here](http://210.45.114.30/gbxu/notice_board/-/boards)提交issue并`@`这两位TA。

# 要求
请利用Flex（可参考[here](http://210.45.114.30/staff/compiler_cminus/blob/master/lab1_lexical_analyzer/Flex%E7%AE%80%E5%8D%95%E4%BD%BF%E7%94%A8.md)），为[C-](http://210.45.114.30/staff/compiler_cminus/blob/master/lab1_lexical_analyzer/CMINUS.md)语言，设计词法分析器。实验要求见[评分标准](http://210.45.114.30/staff/compiler_cminus/blob/master/lab1_lexical_analyzer/%E8%AF%84%E5%88%86%E6%A0%87%E5%87%86.md)
extern int lex_main(int argc, char ** argv);

int main(int argc, char ** argv)
{
	return lex_main(argc, argv);
}

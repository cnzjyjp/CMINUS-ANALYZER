#include "common.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
int getAllTestcase(char filename[][256]){
       int files_count;
	DIR * dir;
	struct dirent * ptr;
	int i=0;
        int j=0;
	dir = opendir("./testcase"); 
	while((ptr = readdir(dir)) != NULL)
	{
	        strcpy(filename[i],ptr->d_name);
	        for(j = 0;;j++) {if(filename[i][j+1]=='.'){break;}}
if((filename[i][j+1]=='.')&&(filename[i][j+2]=='c')&&(filename[i][j+3]=='m')&&(filename[i][j+4]=='i')&&(filename[i][j+5]=='n')&&(filename[i][j+6]=='u')&&(filename[i][j+7]=='s')&&(filename[i][j+8]=='\0'))
               { i++;
                files_count++;}
     else {memset(filename[i],'\0',sizeof(filename[i]));}
    }
    closedir(dir); 
    return (files_count);
}

